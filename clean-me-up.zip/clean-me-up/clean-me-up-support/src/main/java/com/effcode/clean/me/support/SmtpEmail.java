package com.effcode.clean.me.support;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SmtpEmail {

    private String from;
    private String toAddress;
    private String subject;
    private String content;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("SmtpEmail: ");
        sb.append("from=").append(this.from).append("; ");
        sb.append("to=").append(this.toAddress).append("; ");
        sb.append("subject=").append(this.subject).append("; ");
        sb.append("content=").append(this.content);
        return sb.toString();
    }

}
