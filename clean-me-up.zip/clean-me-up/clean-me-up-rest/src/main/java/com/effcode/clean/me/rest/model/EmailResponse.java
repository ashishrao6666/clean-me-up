package com.effcode.clean.me.rest.model;

import org.springframework.http.HttpStatus;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class EmailResponse {

    private String message;
    private HttpStatus statusCode;
    private boolean isMailSent;


    @Override
    public String toString() {
        return "EmailResponse{" +
                "message='" + message + '\'' +
                ", statusCode='" + statusCode + '\'' +
                ", isMailSent=" + isMailSent +
                '}';
    }
}
