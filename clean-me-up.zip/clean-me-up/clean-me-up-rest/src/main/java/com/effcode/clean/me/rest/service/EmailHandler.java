package com.effcode.clean.me.rest.service;

import com.effcode.clean.me.rest.model.EmailRequest;
import com.effcode.clean.me.rest.model.EmailResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.effcode.clean.me.support.SmtpEmail;
import com.effcode.clean.me.support.SmtpHandler;

@Component
public class EmailHandler {
    
    @Autowired
    SmtpHandler smtpHandler;

    private static final Long CONTENT_LENGTH_LIMIT = 65000L;
    private final Logger log = LoggerFactory.getLogger(EmailHandler.class);

    //method to post email
    public EmailResponse send(EmailRequest request) {

        log.debug("To Address: " + request.getToAddress());
        log.debug("Subject: " + request.getSubject());
        log.debug("Content: " + request.getContent());

        EmailResponse response = new EmailResponse();

        if(validateEmailRequest(request)) {
            SmtpEmail smtpEmail = new SmtpEmail();
            smtpEmail.setToAddress(request.getToAddress());
            smtpEmail.setSubject(request.getSubject());
            smtpEmail.setContent(request.getContent());
            smtpHandler.post(smtpEmail);
            log.info("Send email. Adr: " + request.getToAddress() + ", Subject: " + request.getSubject());

            response.setMessage("Mail is sent to "+request.getToAddress());
            response.setStatusCode(HttpStatus.OK);
            response.setMailSent(true);
            return response;
        }
        else{

            response.setMessage("Mail not sent");
            response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR);
            response.setMailSent(false);
        }
        return response;
    }

    // method which checks for email format
    private boolean validateEmailRequest(EmailRequest request){
        boolean result = true;
        if(request.getSubject() == null || request.getToAddress() == null || request.getContent() == null) {
            log.error("Required parameter is null" + request.getSubject() + "|"+ request.getToAddress() + "|"+ request.getContent());
            result = false;
        }
        if(request.getContent()!= null && request.getContent().length() > CONTENT_LENGTH_LIMIT) {
            log.error("Content to BIG: " + request.getContent().length());
            result = false;
        }
        return result;
    }

}
