package com.effcode.clean.me.rest.controller;

import com.effcode.clean.me.rest.model.EmailRequest;
import com.effcode.clean.me.rest.model.EmailResponse;
import com.effcode.clean.me.rest.service.EmailHandler;
import com.effcode.clean.me.support.SmtpHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class EmailApi {

    @Autowired
    EmailHandler emailHandler;

    @Bean
    public SmtpHandler smtpHandler() {
        return new SmtpHandler();
    }

    @PostMapping("/sendEmail")
    public ResponseEntity<EmailResponse> send(@RequestBody EmailRequest request){

        EmailResponse response = emailHandler.send(request);

        if (response.isMailSent()) {
             return  ResponseEntity.accepted().body(response);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

}
