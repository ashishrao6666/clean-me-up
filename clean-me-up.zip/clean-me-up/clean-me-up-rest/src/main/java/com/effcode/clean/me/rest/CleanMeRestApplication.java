package com.effcode.clean.me.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.effcode.clean.me.support.SmtpHandler;
import springfox.documentation.swagger2.annotations.EnableSwagger2;


@SpringBootApplication
@EnableSwagger2
public class CleanMeRestApplication {

    @Bean
    public SmtpHandler smtpHandler() {
        return new SmtpHandler();
    }

    	public static void main(String[] args) {
		SpringApplication.run(CleanMeRestApplication.class, args);
	}
}
