package com.effcode.clean.me.rest.model;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class EmailRequest {

    private String toAddress;
    private String subject;
    private String content;

    @Override
    public String toString() {
        return "EmailRequest{" +
                "toAddress='" + toAddress + '\'' +
                ", subject='" + subject + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
