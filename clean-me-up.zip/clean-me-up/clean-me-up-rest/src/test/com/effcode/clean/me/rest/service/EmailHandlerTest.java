package com.effcode.clean.me.rest.service;

import com.effcode.clean.me.rest.model.EmailRequest;
import com.effcode.clean.me.rest.model.EmailResponse;
import com.effcode.clean.me.support.SmtpHandler;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.mockito.Mockito.doNothing;

@RunWith(SpringJUnit4ClassRunner.class)
public class EmailHandlerTest {
    @Autowired
    SmtpHandler smtpHandler;
    @Autowired
    EmailHandler emailHandler;
    @Test
    public void sendTest(){
        EmailRequest request = new EmailRequest();
        request.setContent("hello");
        request.setSubject("subject");
        request.setToAddress("ashish@gmail.com");
       // initMocks(smtpHandler);
        smtpHandler = Mockito.mock(SmtpHandler.class);
        doNothing().when(smtpHandler).post(Mockito.any());
        EmailResponse response = emailHandler.send(request);

        Assert.assertTrue(response.isMailSent());
        Assert.assertEquals(HttpStatus.OK,response.getStatusCode());
        Assert.assertEquals("Mail sent to"+request.getToAddress(),response.getMessage());

    }

    @Test
    public void sendFailedTest(){
        EmailHandler emailHandler= new EmailHandler();
        EmailRequest request = new EmailRequest();
        emailHandler.send(request);
        EmailResponse response = emailHandler.send(request);
        Assert.assertFalse(response.isMailSent());
        Assert.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,response.getStatusCode());
        Assert.assertEquals("Mail not sent",response.getMessage());
    }

}
